# AGENTS.md

Instructions for AI agents (and humans) working in this repo. Read this first, then the skill or guide you need. If you are setting up or extending the toolkit, the conventions at the bottom are not optional.

What this toolkit is for: the value is the skills, the automations, and the hard-won lessons baked into them, so an agent starts from a working base instead of rediscovering the terrain. The domain packs and the company catalog are starter examples, not the point; a domain can be any subject, and the casts are swappable. Spend your effort on the user's actual problem, not on relearning what the skills already encode.

## The one rule

AI does the draft. You make the call. Nothing reaches a student without a human reading it first. Every skill ends with a guardrail enforcing this. If a change you are about to make would let an AI grade, sanction, or message a student without a human in the loop, do not make it.

## Onboarding a new user (do this first)

When someone points you at this repo or installs these skills and is not sure where to begin, run the `start-here` skill before anything else. It is the front door: it orients the teacher in two sentences, asks a few questions one at a time (what they teach, their biggest time-sink, their LMS, whether any tools are connected), offers to ingest their materials with prof-brain so the other skills are grounded, and then runs one skill on one real example for a fast win. Do not dump the whole skill list on a new user; route them to the single skill that fixes their stated pain, and leave the rest for later. The principle is one ingest, one skill, one result.

Reduce ingestion friction: if their LMS is connected, pull their materials directly rather than asking them to gather files; if not, ask for the smallest useful input (a syllabus and one assignment) and show value before asking for more; if they are copy-paste only, skip ingestion and just run the first skill on a pasted example.

## Skill index: what to reach for

| Skill | Use it when | Folder |
|---|---|---|
| start-here | A new user needs onboarding: orient, ask, ingest, route to a first win | `skills/start-here/` |
| participation-scoring | Grading participation fairly from real activity across channels, DMs, meetings | `skills/participation-scoring/` |
| grading-assistant | Applying a rubric consistently and catching correct-but-differently-worded answers; producing the grading spreadsheet | `skills/grading-assistant/` |
| ai-output-checker | Auditing AI-assisted student work for fabricated or impossible numbers, invented sources, and calculation errors | `skills/ai-output-checker/` |
| class-content-analysis | Auditing your own course materials for gaps, overlap, reading level, alignment, and drift across terms | `skills/class-content-analysis/` |
| exam-rebalance | Checking an exam's difficulty and coverage, simulating six student personas, as qualitative checks, and comparing prior versions | `skills/exam-rebalance/` |
| exam-predictor | Reviewing pre-exam topic evidence; forecasting only with validated historical outcomes | `skills/exam-predictor/` |
| announcement-writer | Drafting class announcements in your captured voice with the AI tells stripped | `skills/announcement-writer/` |
| canvas-page-generator | Turning plain text into a clean, styled course page; capturing brand guidelines | `skills/canvas-page-generator/` |
| quiz-builder | Generating scenario-based question banks that discriminate, in a selectable domain | `skills/quiz-builder/` |
| syllabus-creator | Drafting or refreshing a syllabus from course goals, policies, assessments, dates, and prof-brain memory | `skills/syllabus-creator/` |
| schedule-generator | Creating a detailed spreadsheet schedule with topics, subtopics, assignments, quizzes, exams, and dates | `skills/schedule-generator/` |
| prof-brain | Ingesting all course materials into one organized knowledge base the other skills read from | `skills/prof-brain/` |
| canvas-lms | Operating Canvas reliably from an agent: auth, styled content, grade entry, quiz edits | `skills/canvas-lms/` |

Each skill folder has a `SKILL.md` (the prompt and short how-to, usable immediately) and a `README.md` (the in-depth method, examples, lessons learned). Some carry extra files (grading-assistant ships a spreadsheet template, quiz-builder ships domain packs, canvas-page-generator ships a brand-guidelines template).

## Skill file roles

The repo has two audiences: teachers browsing the project and agents running installed skills. Keep the file roles separate without flattening the detail in the skills.

- `SKILL.md` is the agent runbook and prompt source. It keeps the teaching-specific operating knowledge: what to gather, what can be pulled from tools, the prompt, checks, guardrail, automation notes, and the traps a generic prompt would miss.
- `README.md` is the human field guide. It explains the method, examples, edge cases, and how a teacher, professor, or TA should adapt the skill.
- `examples/` is optional and should be used for concrete synthetic artifacts an agent can imitate. Use placeholders only.
- `_shared/` holds reusable review language, PII checks, LMS handoff patterns, output artifact patterns, and TA workflow patterns.
- `_template/` is the starting point for a new skill. Copy it, then add the real domain detail for the task.

A skill is install-worthy only when it preserves hard-won task detail and still stops at a clear human decision point. Do not make a skill generic by deleting the parts that make it useful.

## Guides: the platform and automation specifics

The skills are LMS-agnostic on purpose. The guides hold the wiring so an educator does not rebuild it.

- `guides/canvas-lms.md` when working with Canvas: authentication, the forced inline styling, pushing content, the three ways to enter grades and the SpeedGrader save bug, quiz and question-bank traps.
- `guides/other-lms.md` for Blackboard, Moodle, Brightspace, Schoology, Google Classroom: auth, read, push grades, push content.
- `guides/chat-and-discussion.md` for participation and announcement sources: LMS forums, Slack, Discord, Teams, Google Classroom, Telegram, WhatsApp, ranked by viability, with rate limits and name-matching gotchas.
- `guides/automation.md` for the agentic tier that every skill points to: drive a browser or connector to pull everything, unify it, store a CSV, analyze across terms.

## Agent compatibility

Read `guides/agents.md` for chat, native-skill, repository, connected, browser, cloud, custom API, and scheduled agents. Read `docs/INDEX.md` for the audience-based documentation map. Installation does not grant tool access. The optional visual guide is in `web/dist/index.html`.

## The three automation tiers

Every skill works at three levels, shown in the skill files as the prompt, the "Automated version", and "Automate even better":

1. Copy-paste: paste the prompt into any AI tool. Zero setup.
2. Connected: an MCP or API connector does the repetitive pulls and pushes.
3. Agentic: an AI browser extension, an agentic browser, or a computer-use agent gathers everything (including archived terms the API will not show), unifies it, and stores it as durable data. See `guides/automation.md`.

Use whatever automation surface the user has. The pattern is the same regardless of brand.

## prof-brain is the context layer

When grounding any skill, prefer reading from the prof-brain knowledge base over asking the user to paste materials again. class-content-analysis, exam-rebalance, exam-predictor, quiz-builder, and announcement-writer all sharpen when pointed at the brain. Keep student PII out of the brain.

## Top-level docs (for humans, and for you)

- `README.md`: the teacher-facing funnel and the three-level ladder (plain chat, chat plus skills, computer control plus skills).
- `INSTALL.md`: the three install paths (copy-paste, Cowork `.skill` bundles, Claude Code script) and how to point an agent at the repo. `scripts/install.py` installs portable skills for multiple agents with previews and backups; `scripts/build-toolkit.py` generates ZIPs, `.skill` files, and the visual guide catalog.
- `GETTING-STARTED.md`: the no-setup first task, plus a level-1-vs-level-3 comparison.
- `GLOSSARY.md` and `FAQ.md`: plain definitions and the common teacher questions.
- `CONTRIBUTING.md`: the contributor path, leading with adding a subject pack.
- `PRINCIPLES.md`: the ethics. `STATUS.md`: the running continuity log.

## Conventions you must follow

- Generic by design. No real student names, no institution branding, no course or quiz IDs, no file paths. Placeholders only: `[COURSE]`, `[ROSTER]`, `[RUBRIC]`, `[COURSE_ID]`, and so on. The persona first names in exam-rebalance are invented archetypes and are allowed.
- Voice. No em dashes, ever. Avoid inflated words (pivotal, crucial, leverage, foster, delve, robust, seamless). Conversational, concrete, lived-experience tone.
- Single source of truth. Prompts live once, in the skills. The cookbook is generated from them by `cookbook/build-cookbook.js`. Never hand-edit `AI-Teaching-Cookbook.docx`. Change a skill, then regenerate.
- Structure. Every skill keeps its sections, including the guardrail. The teaching skills use: the problem, what you need, the prompt, what to check, the guardrail, the automated version, automate even better. Operational skills (canvas-lms, prof-brain) follow the same shape adapted to their job.

## Adding or changing a skill

1. Create `skills/<name>/SKILL.md` with the full section structure, and a `README.md` deep dive.
2. Keep it LMS-agnostic; put platform specifics in a guide and link to it.
3. If it is a copy-paste teaching or authoring skill, add it to the `ORDER` array in `cookbook/build-cookbook.js`. Operational skills stay out of the cookbook.
4. Regenerate the cookbook: `npm ci --prefix cookbook`, then `node cookbook/build-cookbook.js`.
5. Run `./scripts/audit-content.sh` and the four gates before calling it done.

## The four gates (run before shipping)

1. PII scan: no real name, course code, institution reference, or path in any skill, guide, the cookbook, or the article.
2. Voice sweep: zero em dashes; none of the banned words except where a prompt deliberately lists them as words to cut.
3. Cookbook integrity: prompts in the docx match the skills word for word (the docx is generated, not hand-edited).
4. Structure: every skill has its sections, including the guardrail.

## Continuity

`STATUS.md` is the running log of what is done, what is decided, and what is open. Update it after any significant change so a fresh session can resume.

## Build and checks

After edits, run `python3 scripts/build-toolkit.py`, `node cookbook/build-cookbook.js`, `python3 scripts/check-toolkit.py`, and `python3 -m unittest discover -s tests`. Update docs and STATUS.md. Repository-relative paths and documented install destinations are allowed; personal machine paths and student identifiers are not.
