"""Shared, deterministic packaging helpers. No network or third-party dependencies."""
from pathlib import Path
import hashlib
import re
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO_URL = 'https://github.com/TaylorONeal/ai-education/blob/main/'

def skills():
    return sorted(p.parent for p in (ROOT / 'skills').glob('*/SKILL.md'))

def sections(text):
    result = []
    for part in re.split(r'^## ', text, flags=re.M)[1:]:
        heading, _, body = part.partition('\n')
        result.append((heading.strip(), body.strip()))
    return result

def prompt_blocks(text):
    result = []
    for heading, body in sections(text):
        for match in re.finditer(r'(?:^>[^\n]*(?:\n|$))+', body, flags=re.M):
            prompt = '\n'.join(re.sub(r'^> ?', '', line) for line in match.group().rstrip().splitlines()).strip()
            if prompt:
                result.append({'heading': heading, 'text': prompt})
    return result

def portable_files(skill):
    """Resolve shared guide references without installing guides as separate skills."""
    files = {}
    for source in sorted(skill.rglob('*')):
        if not source.is_file() or source.name == '.DS_Store':
            continue
        relative = source.relative_to(skill)
        data = source.read_bytes()
        if source.suffix == '.md':
            text = data.decode('utf-8')
            # References in this toolkit's skill entrypoints and READMEs are root-relative.
            text = text.replace('../../guides/', 'references/toolkit/guides/')
            text = text.replace('../../PRINCIPLES.md', 'references/toolkit/PRINCIPLES.md')
            text = text.replace('../../INSTALL.md', REPO_URL + 'INSTALL.md')
            text = text.replace('../../AGENTS.md', REPO_URL + 'AGENTS.md')
            text = re.sub(r'\.\./([a-z][a-z-]+)/SKILL\.md', lambda m: REPO_URL + 'skills/' + m[1] + '/SKILL.md', text)
            data = text.encode()
        files[relative.as_posix()] = data
    for source in sorted((ROOT / 'guides').glob('*.md')):
        files['references/toolkit/guides/' + source.name] = source.read_bytes()
    files['references/toolkit/PRINCIPLES.md'] = (ROOT / 'PRINCIPLES.md').read_bytes()
    return files

def archive_bytes(destination, entries):
    """Stable bytes make update detection meaningful and eliminate stale ZIP members."""
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(entries.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)

def digest(data):
    return hashlib.sha256(data).hexdigest()
